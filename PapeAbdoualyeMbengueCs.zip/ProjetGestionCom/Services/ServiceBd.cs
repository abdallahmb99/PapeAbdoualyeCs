﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetGestionCom.Entity;

namespace ProjetGestionCom.Services
{
    class ServiceBd
    {
        ModelGestionCom dao = new ModelGestionCom();

        public ServiceBd()
        {

        }



        public Utilisateur SeConnecter(string login, string pwd)
        {
            return dao.Utilisateur.ToList().Where(
                                 u => u.Login.Trim().CompareTo(login) == 0 &&
                                 u.Pwd.Trim().CompareTo(pwd) == 0

                        ).FirstOrDefault();
        }

        public bool CreerUser(Utilisateur user)
        {
            dao.Utilisateur.Add(user);
            return dao.SaveChanges() != 0;
        }

        public void listerUser(DataGridView dtgUser)
        {
            dtgUser.DataSource = dao.Utilisateur.ToList();
        }

        // Articles

        public bool CreerArticle (Article article)
        {
            dao.Article.Add(article);
            return dao.SaveChanges() != 0;
        }

        public void ListerArticle (DataGridView dtgvArticle)
        {
            dtgvArticle.DataSource = dao.Article.ToList();
        }

    }
}
