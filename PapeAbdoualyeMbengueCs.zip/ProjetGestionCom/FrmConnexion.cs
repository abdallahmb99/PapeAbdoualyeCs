﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetGestionCom.Entity;
using ProjetGestionCom.Services;

namespace ProjetGestionCom
{
    public partial class FrmConnexion : Form
    {
        private ServiceBd service = new ServiceBd();

        public FrmConnexion()
        {
            InitializeComponent();
        }

        FrmArticle frmArt = new FrmArticle();

        private void button1_Click(object sender, EventArgs e)
        {
            //Validation
            Utilisateur user = service.SeConnecter(txtLogin.Text.Trim(), txtMdp.Text.Trim());
            if (user == null)
            {
                labelError.Visible = true;
                
            }
            else
            {
                
                frmArt = new FrmArticle();
                frmArt.Show();
                this.Hide();

            }

           
        }

        InscriptionEtLister frmInscription = new InscriptionEtLister();

        private void btnInscrire_Click(object sender, EventArgs e)
        {
            frmInscription = new InscriptionEtLister();
            frmInscription.Show();
            this.Hide();
        }
    }
}
