﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetGestionCom.Entity;
using ProjetGestionCom.Services;

namespace ProjetGestionCom
{
    public partial class InscriptionEtLister : Form
    {
        private ServiceBd service = new ServiceBd();

        public InscriptionEtLister()
        {
            InitializeComponent();
            service.listerUser(dtgvUser);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void InscriptionEtLister_Load(object sender, EventArgs e)
        {

            service.listerUser(dtgvUser);

        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            Utilisateur user = new Utilisateur()
            {
                Login = txtLogin.Text,
                Pwd = txtPwd.Text,
                Nom = txtNom.Text,
                Prenom = txtPrenom.Text,
                Profil = cboProfil.SelectedItem.ToString()
            };

            service.CreerUser(user);
            service.listerUser(dtgvUser);
        }
    }
}
