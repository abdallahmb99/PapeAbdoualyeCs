﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetGestionCom.Entity;
using ProjetGestionCom.Services;

namespace ProjetGestionCom
{
    public partial class FrmArticle : Form
    {
        private ServiceBd service = new ServiceBd();

        public FrmArticle()
        {
            InitializeComponent();
            service.ListerArticle(dtgvArticle);
            
        }

        private void Article_Load(object sender, EventArgs e)
        {
            service.ListerArticle(dtgvArticle);
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            Article article = new Article()
            {


                Reference = txtReference.Text,
                Libelle = txtLibelle.Text,
                Stock = float.Parse(txtStock.Text),
                Prix = float.Parse(txtPrix.Text),
               // Categorie = cboCategorie.SelectedItem.ToString()
            };

            service.CreerArticle(article);
            service.ListerArticle(dtgvArticle);
        }
    }
}
